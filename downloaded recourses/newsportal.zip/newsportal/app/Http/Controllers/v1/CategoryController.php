<?php

namespace App\Http\Controllers\v1;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $categories = Category::query();
        $data["categories"] = $categories->get();
        $data["pluck_categories"] = $categories->whereNull("parent_category_id")->pluck("name","id");
        return view("admin.configuration.category.index")->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }


    public function store(Request $request)
    {
        $this->validate($request,[
            'name'=>['required',Rule::unique("categories")->whereNull("parent_category_id")],
            "bn_name"=>'required',
            'parent_category_id'=>'nullable'
        ]);

        $data = $request->only(['name','bn_name','parent_category_id']);
        Category::query()->create($data);
        session()->flash("success","Category saved");
        return redirect()->route("category.index");
    }


    public function show($id)
    {
        //
    }


    public function edit($id)
    {
        $data["category"] = Category::query()->findOrFail($id);
        $data["pluck_categories"] = Category::query()->whereNull("parent_category_id")->pluck("name","id");
        return view("admin.configuration.category.edit-category")->with($data);
    }


    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'name'=>['required',Rule::unique("categories")->ignore($id)],
            "bn_name"=>'required',
            'parent_category_id'=>'nullable'
        ]);

        $data = $request->only('name','bn_name','parent_category_id');
        $category = Category::query()->findOrFail($id);
        $category->update($data);
        session()->flash("success","Category updated");
        return redirect()->route("category.index");
    }


    public function destroy($id)
    {
        //
    }
}
