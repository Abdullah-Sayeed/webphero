<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;
    protected $table = 'categories';
    protected $fillable=[ 'name', 'bn_name', 'image', 'details', 'parent_category_id', 'isActive', 'posts'];

    public function category(){
        return $this->belongsTo(Category::class,"parent_category_id");
    }

    public function categories(){
        return $this->hasMany(Category::class,"parent_category_id");
    }

}
