<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCategoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('categories', function (Blueprint $table) {
            $table->id();
            $table->string('name')->nullable();
            $table->string('bn_name')->nullable();
            $table->string('image')->nullable()->comment('Category Display Image');
            $table->text('details')->nullable()->comment('If Details need');
            $table->unsignedBigInteger('parent_category_id')->nullable()->comment('Parent id of Sub Category');
            $table->integer('isActive')->default(1)->comment('1=Active,2=Inactive');
            $table->integer('posts')->default(0)->comment('Category wise posted posts/news amount');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('categories');
    }
}
