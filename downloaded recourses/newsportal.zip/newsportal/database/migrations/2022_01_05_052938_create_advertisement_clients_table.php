<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAdvertisementClientsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('advertisement_clients', function (Blueprint $table) {
            $table->id();
            $table->string('name')->nullable()->comment('Client Full name');
            $table->string('phone')->nullable()->comment('Client Phone Number');
            $table->string('documents')->nullable()->comment('Client Documents. Ex. NID pictures, Other docs image');
            $table->string('email')->nullable()->comment('Client Email');
            $table->longText('address')->nullable()->comment('Client address');
            $table->string('facebook')->nullable();
            $table->string('whatsapp')->nullable();
            $table->integer('total_ads')->nullable();
            $table->integer('isDiamond')->default(0)->comment('Client Status Ex. 0=General,1=Silver,2=Gold,3=Diamond,4=Platinum');
            $table->softDeletes();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('advertisement_clients');
    }
}
