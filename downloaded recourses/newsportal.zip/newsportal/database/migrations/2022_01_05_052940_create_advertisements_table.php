<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAdvertisementsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('advertisements', function (Blueprint $table) {
            $table->id();
            $table->foreignId('advertisement_client_id')->nullable()->constrained();
            $table->string('title')->nullable();
            $table->string('image_banner')->nullable();
            $table->string('video_link')->nullable();
            $table->text('body')->nullable();
            $table->dateTime('start_datetime')->nullable()->comment('Advertisement Start Date Time');
            $table->dateTime('end_datetime')->nullable()->comment('Advertisement End Date Time');
            $table->integer('status')->default(1)->comment('Ex. 0=Declined,1=Pending,2=Active,3=Closed,4=Hold');
            $table->integer('isPaid')->nullable()->comment('Ex. 0=Not paid,1=Dues,2=Full Paid');
            $table->longText('note')->nullable();
            $table->unsignedBigInteger('createdBy')->nullable()->comment('Creator of the advertisement ');
            $table->unsignedBigInteger('approvedBy')->nullable()->comment('Approved By of the advertisement ');
            $table->longText('status_note')->nullable()->comment('Success/Decline/Hold Reason details');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('advertisements');
    }
}
