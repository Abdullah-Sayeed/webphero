<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateNewsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('news', function (Blueprint $table) {
            $table->id();
            $table->string('title')->nullable()->comment('Ex. News Title');
            $table->string('slug')->nullable()->comment('Ex. News slug');
            $table->foreignId('country_id')->nullable()->constrained();
            $table->foreignId('division_id')->nullable()->constrained();
            $table->foreignId('city_id')->nullable()->constrained();
            $table->foreignId('upazila_id')->nullable()->constrained();
            $table->foreignId('category_id')->nullable()->comment('Primary id of categories table.');
            $table->longText('details')->nullable();
            $table->string('video_link')->nullable();
            $table->string('thumbnail')->nullable();
            $table->date('date')->nullable();
            $table->integer('read_time')->default(5)->comment('Reading Time');
            $table->integer('isActive')->default(0)->comment('Ex. 0=InActive,1=Active');
            $table->foreignId('news_type_id')->nullable()->comment('Primary id of the news_types');
            $table->foreignId('createdBy')->nullable()->comment('News Created By');
            $table->foreignId('approvedBy')->nullable()->comment('News Approved By');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('news');
    }
}
