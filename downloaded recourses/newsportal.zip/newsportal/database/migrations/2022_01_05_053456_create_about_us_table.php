<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAboutUsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('about_us', function (Blueprint $table) {
            $table->id();
            $table->string('company')->nullable();
            $table->longText('about')->nullable();
            $table->longText('mission')->nullable();
            $table->string('mission_picture')->nullable();
            $table->string('mission_path_link')->nullable();
            $table->longText('vision')->nullable();
            $table->string('vision_picture')->nullable();
            $table->string('vision_path_link')->nullable();
            $table->unsignedBigInteger('createdBy')->nullable();
            $table->string('picture')->nullable();
            $table->string('logo')->nullable();
            $table->string('footer_logo')->nullable();
            $table->string('favicon')->nullable();
            $table->string('android_app_icon')->nullable();
            $table->string('ios_app_icon')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('about_us');
    }
}
